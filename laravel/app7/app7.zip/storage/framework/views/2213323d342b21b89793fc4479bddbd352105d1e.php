<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
		<div class="col-md-3">
            <div class="card">
                <div class="card-header">Notes</div>
				<table class="table">
				<?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
					  <td><?php echo e($note->text); ?></td>
			    	</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		   	</table>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
					<table class="table">
					    <tr>
							<th>Note</th>
						</tr>
					<?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						  <td><?php echo e($note->text); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
                </div>
            </div>
        <?php if(Route::has('login')): ?>
		 <div class="card text-center">
			<?php if(auth()->guard()->check()): ?>
				<a href="<?php echo e(url('/logout')); ?>">Logout</a>
			<?php else: ?>
				<a href="<?php echo e(route('login')); ?>">Login</a>
				<a href="<?php echo e(route('register')); ?>">Register</a>
			<?php endif; ?>
		 </div>
        <?php endif; ?>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>