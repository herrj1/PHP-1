@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
		<div class="col-md-3">
            <div class="card">
                <div class="card-header">Notes</div>
				<table class="table">
				@foreach($notes as $note)
					<tr>
					  <td>{{ $note->text }}</td>
			    	</tr>
				@endforeach
		   	</table>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in!
					<table class="table">
					    <tr>
							<th>Note</th>
						</tr>
					@foreach($notes as $note)
						<tr>
						  <td>{{ $note->text }}</td>
						</tr>
					@endforeach
					</table>
                </div>
            </div>
        @if (Route::has('login'))
		 <div class="card text-center">
			@auth
				<a href="{{ url('/logout') }}">Logout</a>
			@else
				<a href="{{ route('login') }}">Login</a>
				<a href="{{ route('register') }}">Register</a>
			@endauth
		 </div>
        @endif
		</div>
    </div>
</div>
@endsection
