<?php
namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\Event;

class PostsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('RequestHandler');
        $this->loadComponent('Flash');

    }
	
	public function index(){
		$this->Crud->on('beforePaginate', function(Event $event){
			$event->subject->query = $event->subject->query->find('search', $this->request->query);
		});
		return $this->Crud->execute();
	}
}
