<?php
namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\Event;

class AppController extends Controller
{
	use \Crud\Controller\ControllerTrait;
    public function initialize()
    {
        parent::initialize();

        $this->loadComponent('RequestHandler');
        $this->loadComponent('Flash');

        /*
         * Enable the following components for recommended CakePHP security settings.
         * see https://book.cakephp.org/3.0/en/controllers/components/security.html
         */
        //$this->loadComponent('Security');
        //$this->loadComponent('Csrf');
		
		$this->viewClass = 'CrudView\View\CrudView';
		$this->loadComponent('Crud.Crud',[
			'actions' => [
				'Crud.Index',
				'Crud.View',
				'Crud.Edit',
				'Crud.Delete',
				'Crud.Lookup',
			],
			'listeners' => [
				'CrudView.View',
				'Crud.Redirect',
				'Crud.RelatedModels',
				'Crud.Search',
				'Crud.Api',
				'Crud.ApiQueryLog',
			]
		]);
		$this->loadComponent('Search.Prg', [
			'actions' => ['index']
		]);
    }
	
	public function beforeFilter(Event $event){
		$action = $this->Crud->action();
		$action->config('scaffold.actions_blacklist', ['lookup']);
	}
}
